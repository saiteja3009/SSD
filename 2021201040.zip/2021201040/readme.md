Assignment - 1 : Bash Scripting 

Software Systems Development


Q1.
du -sh command is used to get all files along with the sizes in human readable format. */ is used to get only the directories then awk command to remove the '/' at the end of each directory name using substr and to add tab spaces,"\t" is used. The output of the file is given in the reverse sorted using sort -rh, and it is given in MB, KB, B format for specific directories.(Because of the difference in the lengths of the names of the directories they are not aligned).It prints all the directory names along with the sizes, given atleast one directory is present(assumption).

Q2.
The input.txt and output.txt are read as the arguments while execution of the program. awk command is used along with length and RS to remove spaces between the words in the file to check for the match for all the words in a single line using grep command. -i is used to ignore the case sensitivity of ing in the given file. At last tr is used to convert all the characters of words into lower case from uppercase, if present. Then > is used to create the file and store the contents in it.

Q3.
Using compgen -c, all possible command keywords are stored into the temporary file(temp.txt). Instead of finding all the permuatation of the input word and comparing it with all possible command keywords, here the input word is sorted and then we try to find all the words from temporary file(temp.txt)with the same length of the input word, then store them in another temporary fle(temp2.txt). To make it more efficient, comparison is only done when the length of input word and command word are same i.e from the temp2.txt. For sorting a specific string, grep -o . along with sort is used and tr -d "\n" is used to remove new lines, so that we can store it in a variable. All the contents are stored into temp.txt if they match with input word, if there are no words in file then NO is printed, if there are words then the words are printed with tab spaced.

Q4.
Here according to the inputs different functions are called.(Only for Valid Inputs). fun function is used to convert roman to integer and fun2 function is used to convert integer to roman, both the functions are pretty straight forward codes(using arrays, loops, conditional statements). According to the input the corresponding output gets printed on terminal. In the main code =~ is used for pattern matching.

Q5.
mkdir is used for creating directory and cd for changing directory. && is used for combining both command into one line. touch is used for creating files. temp{1..50}.txt will create temp1.txt, temp2.txt, temp3.txt.... lab50.txt in one go.
ls is used to list the first half of the files and then sed command is used to change the extension from .txt to .md using mv to remove the .txt files. sed is used to modify all the names of the files in the directory. xargs reads items from standard input as separated by blanks and executes a command once for each argument(n2 reads 2 arguments). mv command is used for renaming file. zip command is used to zip all the files with .txt files only.