#!/bin/bash
func(){
local var=$(echo $1 | grep -o . | sort | tr -d "\n" )
echo $var
}

compgen -c > temp.txt
c=$(func $1)
v=${#c}
n=0
awk 'length($1) == '$v' {print $1}' temp.txt | sort -u > temp2.txt
res="YES "
m=0
cat temp2.txt | while read LINE; 
 do 
 k=$(func $LINE)
 if [[ $k == $c ]]
 then
 if [[ $m == 0 ]]
 then
 echo -ne YES'\t'$LINE
 m=1
 n=2
 else
 echo -ne '\t'$LINE
 fi
 #echo $LINE;
 fi 
 done > temp.txt
 [ -s temp.txt ] && cat temp.txt || echo -n "NO"
 rm temp.txt
 rm temp2.txt
 #echo $?
 #if [[ $? == 0 ]]
 #then
 #echo "NO"
 #else
 #cat temp.txt
 #fi
