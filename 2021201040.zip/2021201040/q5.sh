# !/bin/bash
mkdir temp_activity && cd temp_activity
touch temp{1..50}.txt
ls temp{1..25}.txt | sed 's/^\(.*\)\.txt$/mv "\1.txt" "\1.md"/' | sh
ls temp{1..50}.* | sed 'p;s/\./\\_modified./' | xargs -n2 mv
zip txt_compressed.zip *.txt
#for f in $files; do mv -- "$f" "${f%.txt}.md"; done
#ls temp{1..50}.* | for f in *; do mv $f $f_modified; done

