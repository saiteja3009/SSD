#!/bin/bash
du -sh */ | sort -rh | awk '{$NF=substr($NF,1,length($NF)-1); print $NF "\t" $1}'
