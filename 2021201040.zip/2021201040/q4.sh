#!/bin/bash
value(){
if [[ $1 == 'I' ]]
then
func=1
fi
if [[ $1 == 'V' ]]
then
func=5
fi
if [[ $1 == 'X' ]]
then
func=10
fi
if [[ $1 == 'L' ]]
then
func=50
fi
if [[ $1 == 'C' ]]
then
func=100
fi
if [[ $1 == 'D' ]]
then
func=500
fi
if [[ $1 == 'M' ]]
then
func=1000
fi
return
}


fun(){
func=0
str=$1
res=0
len=${#str}
len1=$(($len-1))
prev=0
for ((i=len1; i>=0;i--))
do
x=${str:i:1}
value $x
#echo $res
if [[ "$func" -ge "$prev" ]]
then
res=$(($res+$func))
else
res=$(($res-$func))
fi
prev=$(($func))
done
echo $res
}


fun2(){
arr=(I IV V IX X XL L XC C CD D CM M)
num=(1 4 5 9 10 40 50 90 100 400 500 900 1000)
i=12
cur=$1
res=""
while [[ $cur > 0 ]]
do
a=$(($cur/${num[i]}))
cur=$(($cur%${num[i]}))
while [[ $a > 0 ]]
do
#echo $cur $a
res=$res${arr[i]}
a=$(($a-1))
done
i=$(($i-1))
done
echo $res
}

if [ $# == 2 ]
then
if [[ $1 =~ ^[0-9]+$ ]]
then
x=$(($1 + $2))
fun2 $x
else
x=$(fun $1)
y=$(fun $2)
echo $((x+y))
fi 
else
fun2 $1
fi


